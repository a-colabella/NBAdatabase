Group Name: ColabellaFoleySayasith

Group Members:
Andrew Colabella
Sean Foley
Peyton Sayasith

Project Description:
Basketball is one of the America's most beloved and followed sports and is gaining increasing popularity the world over. As with any sport, teams of people are employed to record and analyze a plethora of statistics. Within the NBA, there is the opportunity to explore players, teams, and games.  We’re big NBA fans and are hoping to be able to create a resource that we will be able to use beyond this class.
We plan to provide a SQL database providing users the ability to store and update information about the NBA.  We will use Python’s Tkinter library to develop this application.  No plans are currently in place for specific hardware beyond the usage of a computer to host the server.  